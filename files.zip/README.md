# My Portfolio

A simple portfolio web page showcasing your expertise.

## Structure

```
/my-portfolio
├── index.html
├── style.css
├── app.js
└── CV.pdf
```

## Usage

1. Replace `YOUR_USERNAME` in `index.html` with your actual GitHub and LinkedIn usernames.
2. Replace `Your Name` with your real name.
3. Add your own `CV.pdf` to the project.
4. Customize content and styles as you like.

## Deployment

To deploy:
- Push to GitHub (`git push origin main`)
- Enable GitHub Pages in repository settings (set branch to `main` and folder to `/` root)

Your portfolio will be live at `https://YOUR_USERNAME.github.io/portfolio/`